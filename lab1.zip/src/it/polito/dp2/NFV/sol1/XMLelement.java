package it.polito.dp2.NFV.sol1;

public interface XMLelement {
	
	public void addElement(XMLelement element); 
	
	public void removeElement(XMLelement element);

}
