package it.polito.dp2.NFV.sol1;

import it.polito.dp2.NFV.sol1.jaxb.NodeType;

public class NodeXMLelement extends NodeType implements XMLelement {

	//List<LinkType> linkList;
	
	@Override
	public void addElement(XMLelement element) {
		
	}

	@Override
	public void removeElement(XMLelement element) {
		
	}

}
