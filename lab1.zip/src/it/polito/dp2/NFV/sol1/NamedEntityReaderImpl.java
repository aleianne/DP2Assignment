package it.polito.dp2.NFV.sol1;

import it.polito.dp2.NFV.NamedEntityReader;

class NamedEntityReaderImpl implements NamedEntityReader {

	@Override
	public String getName() {
		return null;
	}

}
